for i in {0..9}
do
APPID=$(aws amplify list-apps --output json --query 'apps['$i'].appId'| tr -d '"' 2> /dev/null)
JOBID=$(aws amplify list-jobs --app-id $APPID --branch-name master --query 'jobSummaries[0].jobId'| tr -d '"' 2> /dev/null)
aws amplify stop-job --app-id $APPID --branch-name master --job-id $JOBID

done
