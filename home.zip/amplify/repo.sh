aws configure set region us-east-1
aws codecommit create-repository --repository-name test

./code.sh


aws configure set region us-east-2
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region us-east-2"

aws configure set region us-west-1
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region us-west-1"

aws configure set region us-west-2
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region us-west-2"

aws configure set region ap-northeast-1
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region ap-northeast-1"

aws configure set region ap-northeast-2
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region ap-northeast-2"

aws configure set region ap-southeast-1
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region ap-southeast-1"

aws configure set region ap-southeast-2
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region ap-southeast-2"

aws configure set region ca-central-1
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region ca-central-1"

aws configure set region eu-central-1
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region eu-central-1"

aws configure set region eu-west-1
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region eu-west-1"

aws configure set region eu-west-2
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region eu-west-2"

aws configure set region ap-south-1
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region ap-south-1"

aws configure set region eu-west-3
aws codecommit create-repository --repository-name test

./code.sh

aws configure set region eu-north-1
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region eu-west-3"

aws configure set region sa-east-1
aws codecommit create-repository --repository-name test

./code.sh


echo "$QUOTA == region sa-east-1"


