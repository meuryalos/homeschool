aws configure set region us-east-1
./sup0.sh

aws configure set region us-east-2
./sup0.sh

aws configure set region us-west-1
./sup0.sh

aws configure set region us-west-2
./sup0.sh

aws configure set region ap-northeast-1
./sup0.sh

aws configure set region ap-northeast-2
./sup0.sh

aws configure set region ap-southeast-1
./sup0.sh

aws configure set region ap-southeast-2
./sup0.sh

aws configure set region ca-central-1
./sup0.sh

aws configure set region eu-central-1
./sup0.sh

aws configure set region eu-west-1
./sup0.sh

aws configure set region eu-west-2
./sup0.sh

aws configure set region ap-south-1
./sup0.sh

aws configure set region eu-west-3
./sup0.sh

aws configure set region eu-north-1

./sup0.sh

aws configure set region sa-east-1
./sup0.sh

